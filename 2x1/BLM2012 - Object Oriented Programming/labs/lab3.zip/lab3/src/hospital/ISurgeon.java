package hospital;

public interface ISurgeon {
    void performSurgery() throws SurgeryUnsuccessfulException;
}
