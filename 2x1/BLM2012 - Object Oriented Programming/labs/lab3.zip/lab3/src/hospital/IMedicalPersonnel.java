package hospital;

public interface IMedicalPersonnel {
    String getName();
}
